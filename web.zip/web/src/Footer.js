import React, { Component } from 'react';
class Footer extends Component{
 render(){
   return (
     <div className="footer">
      <a href="#"><strong className="scolor">Contact us: newsonline@gmail.com</strong></a>
     </div>
    );
 }
}

export default Footer;
