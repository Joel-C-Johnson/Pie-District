/**
 * @module src/HomePage
 *
 * Component that display Homepage with Login
 * Accepts the following properties:
 *  - email: enter email for signin
 *  - password: enter the same password which you have enter at the time of signup
 * Also forgot password
 * Also create account option 
 *
*/

import React, { Component } from 'react';
import { Link } from 'react-router';
import Footer from './Footer';
import { Navbar, Nav, NavItem } from 'react-bootstrap';
import SigninForm from './SigninForm';

class Header extends Component {
  render() {
    return (
      <div>
        <Navbar inverse>
          <Navbar.Header><Navbar.Brand>
            <a href="/homepage"><span className='glyphicon glyphicon-home scolor'></span>&nbsp; <strong className="scolor">Home</strong></a>
            <a href="/homepage">&nbsp;&nbsp; <strong className="scolor">Admin</strong></a>
          </Navbar.Brand><Navbar.Toggle />
          </Navbar.Header>
          <Navbar.Collapse >
            <Nav className="pull-right">
              <NavItem eventKey={1} ><Link to={'/signin'}><span className="glyphicon glyphicon-user scolor"></span><strong className="scolor">Login</strong></Link></NavItem>
              <NavItem eventKey={2} ><Link to={'/signup'}><span className="glyphicon glyphicon-user scolor"></span><strong className="scolor">Signup</strong></Link></NavItem>
            </Nav>
          </Navbar.Collapse>
        </Navbar>
      </div>
    );
  }
}

class HomePage extends Component {
  render() {
    window.localStorage.clear();
    return (
      <div>
        <div>
          <Header />
        </div>

        <div className="container-fluid">
          <div className="row ">
            <div className="col-md-3 boxColor divSpace">
              <h2 >Just Posted</h2>
              <div class="content">
                <img class="rail-article-photo" src="https://timedotcom.files.wordpress.com/2017/09/chipotle-queso.jpg?quality=85&amp;w=74&amp;h=74&amp;crop=1" />
                <h3 className="fonth4">
                  <a class="article-permalink" href="http://time.com/5032403/chipotle-free-chips-guac-queso/?xid=homepage" data-event="left-hand-rail">Chipotle Is Offering Free Chips and Guac or Queso. Here&#8217;s How to Get It</a>
                  {/* <time datetime="2017-11-21 00:25:43">7:25 PM ET</time> */}
                </h3>
              </div>

              <div class="content">
                <img class="rail-article-photo" src="http://timedotcom.files.wordpress.com/2017/08/taylor-swift-music-video-01.jpg?quality=85&amp;crop=705px%2C37px%2C426px%2C426px&amp;resize=74%2C74&amp;strip" />
                <h3 className="fonth4">
                  <a class="article-permalink" href="http://time.com/4928223/taylor-swift-beefs-guide/?xid=homepage" data-event="left-hand-rail">A Comprehensive Guide to Taylor Swift’s Feuds</a>
                </h3>

              </div>
              <div class="rail-article format-article  has-thumbnail " data-article="5029186">
                <div class="content">
                  <img class="rail-article-photo" src="https://timedotcom.files.wordpress.com/2017/11/colbert1.jpg?quality=85&amp;w=74&amp;h=74&amp;crop=1" />
                  <h3 className="fonth4">
                    <a class="article-permalink" href="http://time.com/5029186/stephen-colbert-on-al-franken/?xid=homepage" data-event="left-hand-rail">Stephen Colbert Is Having Absolutely None of Al Franken’s Apology</a>
                  </h3>
                </div>
                <img alt="" src={require('./no.png')} />
              </div>
            </div>


            <div className="col-md-5 boxColor divSpace">
              <h2 text-align="center"> <font color="black">THE</font>          <font color="red">BRIEF</font></h2>
              <img alt="" src={require('./a.png')} />
              <h2 className="fonth1"><a href="http://time.com/5032590/charlie-rose-sexual-harrassment/?xid=homepage" data-event="the-brief">Charlie Rose Suspended </a>
              </h2>
              <p class="home-excerpt">
                Television host and journalist Charlie Rose apologized for his "inappropriate behavior" after eight women accused him of sexual harassment. CBS News, Bloomberg, and PBS all suspended their work with Rose in the wake of the allegations
				        </p>

              <div class="home-brief-title-and-excerpt">
                <h2 className="fonth1"><a href="http://time.com/5032394/justice-department-time-warner-att-deal/?xid=homepage" data-event="the-brief">DOJ Will Sue to Stop AT&amp;T-Time Warner Merger</a>
                </h2>
                <p class="home-excerpt">The Justice Department intends to sue AT&amp;T to stop its $85 billion purchase of Time Warner. That sets the stage for a legal battle between the Trump Administration and AT&amp;T</p>
              </div>

              <div class="home-brief-title-and-excerpt">
                <h2 className="fonth1"><a href="http://time.com/5031986/della-reese-death-obituary/?xid=homepage" data-event="the-brief">Singer and Actress Della Reese Dies at 86</a>
                </h2>
                <p class="home-excerpt">
                  Della Reese, the actress and gospel-influenced singer who in middle age found her greatest fame as Tess, the wise angel in the long-running television drama <i>Touched by an Angel</i>, has died at age 86</p>
              </div>
            </div>

            <div className="col-md-3 boxColor divSpace">
              <h4>CAST YOUR VOTE</h4>
              <img alt="" src={require('./m.png')} />
              <h2>Featured</h2>
              <div class="home-columnists-author-and-title  home-icons-article ">
                <h3 class="home-columnists-author"><a href="http://time.com/author/melinda-gates/">Melinda Gates</a></h3>
                <h4>Melinda Gates: The World is Finally Listening. Me too. Me too. Me too.</h4>
              </div>
              <div class="home-columnists-author-and-title home-columnists-author-and-title-no-hero home-icons-video ">
                <h3 class="home-columnists-author"><a href="http://time.com/author/elizabeth-dias/">Elizabeth Dias</a></h3>
                <h4>The Family Behind a $500 Million Bible Museum Hopes to Change Washington</h4>
              </div>
              <div class="home-columnists-author-and-title home-columnists-author-and-title-no-hero home-icons-article ">
                <h3 class="home-columnists-author"><a href="http://time.com/author/p-nash-jenkins/">Nash Jenkins</a></h3>
                <h4>How Sexual Misconduct Scandals Are Already Reshaping the 2020 Democratic Primary</h4>
              </div>
              <article class="home-columnists-article border-separated-article ">
                <div class="home-columnists-author-and-title home-columnists-author-and-title-no-hero home-icons-article ">
                  <h3 class="home-columnists-author"><a href="http://time.com/author/susanna-schrobsdorff/">Susanna Schrobsdorff</a></h3>
                  <h4>The Cruel Math of Finding a Nursing Home for My Dad</h4>
                </div>
              </article>
            </div>
          </div>
        </div>

        <div>
          <Footer />
        </div>
      </div>
    );
  }
}

export default HomePage;
